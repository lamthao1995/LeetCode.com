public class Solution {
    public int bulbSwitch(int n) {
        return (int)Math.pow(n, 0.5);
    }
}